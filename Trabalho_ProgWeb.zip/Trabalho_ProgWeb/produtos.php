<?php

?>
<!DOCTYPE html>
<html>
<head>	<title>Produtos</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header id="topo">
		<h1>Catálogo de Produtos</h1>
	</header>
	<div class="menu_produtos">
		<nav>
			<ul>
			    <li><a href="index.php">Home</a></li>
			    <li><a href="carrinho.php">Carinho de Compras</a></li>
			    <li><a href="quem_somos.php">Quem Somos</a></li>
		    </ul>
		</nav>
	</div>
	<div class="catalogo">
		<div class="produto">
			<div class="foto">
				<img src="produto.png">
			</div>
			<div class="informacoes_produtos">
				<span class="nome_produto">Produto1</span>
				<span class="descricao_produto">Descrição do produto</span>
				<span class="valor_produto">R$100,00</span>
			</div>
		</div>
		<div class="produto">
			<div class="foto">
				<img src="produto.png">
			</div>
			<div class="informacoes_produtos">
				<span class="nome_produto">Produto1</span>
				<span class="descricao_produto">Descrição do produto</span>
				<span class="valor_produto">R$100,00</span>
			</div>
		</div>
		
		<div class="produto">
			<div class="foto">
				<img src="produto.png">
			</div>
			<div class="informacoes_produtos">
				<span class="nome_produto">Produto1</span>
				<span class="descricao_produto">Descrição do produto</span>			
				<span class="valor_produto">R$100,00</span>
			</div>
		</div>
	</div>
</body>
</html>