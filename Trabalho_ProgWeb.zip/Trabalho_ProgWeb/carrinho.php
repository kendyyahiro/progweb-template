<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Carrinho de Compras</title>
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<header id="topo">
		<h1>Carrinho de Compras</h1>
	</header>
	<div class="menu_produtos">
		<nav>
			<ul>
			    <li><a href="index.php">Home</a></li>
			    <li><a href="produtos.php">Produtos</a></li>
			    <li><a href="quem_somos.php">Quem Somos</a></li>
		    </ul>
		</nav>
	</div>
	<div class="carrinho">
		<span class="carrinho_nome_produto">Carro</span>
		<span class="carrinho_descricao_produto">Chevrolet Onix 1.6 2016</span>
		<span><img src="onix.jpg"></span>
		<span class="carrinho_valor_produto">R$ 32.942</span>
		<span class="carrinho_quantidade_produto">1</span>
		<button class="remover_produto">Remover</button>
	</div>
	<div class="carrinho">
		<span class="carrinho_nome_produto">Carro</span>
		<span class="carrinho_descricao_produto">Chevrolet Onix 1.6 2016</span>
		<span><img src="onix.jpg"></span>
		<span class="carrinho_valor_produto">R$ 32.942</span>
		<span class="carrinho_quantidade_produto">1</span>
		<button class="remover_produto">Remover</button>
	</div>
	<div class="carrinho">
		<span class="carrinho_nome_produto">Carro</span>
		<span class="carrinho_descricao_produto">Chevrolet Onix 1.6 2016</span>
		<span><img src="onix.jpg"></span>
		<span class="carrinho_valor_produto">R$ 32.942</span>
		<span class="carrinho_quantidade_produto">1</span>
		<button class="remover_produto">Remover</button>
	</div>
	<div class="carrinho">
		<span class="carrinho_nome_produto">Carro</span>
		<span class="carrinho_descricao_produto">Chevrolet Onix 1.6 2016</span>
		<span><img src="onix.jpg"></span>
		<span class="carrinho_valor_produto">R$ 32.942</span>
		<span class="carrinho_quantidade_produto">1</span>
		<button class="remover_produto">Remover</button>
	</div>
</body>
</html>