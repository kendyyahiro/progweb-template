<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Quem Somos</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header id="topo">
		<h1>Quem Somos</h1>
	</header>
	<div class="envolto">
		<div class="perfil">
			<div class="foto">
				<img src="foto.png">
			</div>
			<div class="informacoes_perfil">
				<span class="nome">Geovanna Santiago</span>
	      		<span class="email">souza.geovanna@ufms.br</span>
			</div>
		</div>
		<div class="perfil">
			<div class="foto">
				<img src="foto.png">
			</div>
			<div class="informacoes_perfil">
				<span class="nome">Geovanna Santiago</span>
	      		<span class="email">souza.geovanna@ufms.br</span>
			</div>
		</div>
		<div class="perfil">
			<div class="foto">
				<img src="foto.png">
			</div>
			<div class="informacoes_perfil">
				<span class="nome">Geovanna Santiago</span>
	      		<span class="email">souza.geovanna@ufms.br</span>
			</div>
		</div>
		<div class="perfil">
			<div class="foto">
				<img src="foto.png">
			</div>
			<div class="informacoes_perfil">
				<span class="nome">Geovanna Santiago</span>
	      		<span class="email">souza.geovanna@ufms.br</span>
			</div>
		</div>
		<div class="perfil">
			<div class="foto">
				<img src="foto.png">
			</div>
			<div class="informacoes_perfil">
				<span class="nome">Geovanna Santiago</span>
	      		<span class="email">souza.geovanna@ufms.br</span>
			</div>
		</div>
	</div>
	<div class="menu_return">
		<nav>
			<ul>
			    <li><a href="index.php">Home</a></li>
			    <li><a href="produtos.php">Produtos</a></li>
			    <li><a href="carrinho.php">Carinho de Compras</a></li>
		    </ul>
		</nav>
	</div>
</body>

</html>