<?php

?>
<!DOCTYPE html>
<html>
<head>
	<title>Procure Aqui!</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<center>
		<header id="topo">
				<h1>Seja bem-vindo</h1>
		</header>
			<nav class="menu_home">
			    <ul>
			        <li><a href="produtos.php">Produtos</a></li>
			        <li><a href="carrinho.php">Carinho de Compras</a></li>
			        <li><a href="quem_somos.php">Quem Somos</a></li>
			    </ul>
			</nav>		
	</center>
</body>
</html>